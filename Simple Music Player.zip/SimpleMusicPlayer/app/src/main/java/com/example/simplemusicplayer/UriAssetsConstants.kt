package com.example.simplemusicplayer

class UriAssetsConstants {
    companion object {
        const val fireside = "asset:///Fireside.mp3"
    }
}