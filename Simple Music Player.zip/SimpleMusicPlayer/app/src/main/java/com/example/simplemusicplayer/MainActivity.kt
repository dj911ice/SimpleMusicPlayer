package com.example.simplemusicplayer

import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.simplemusicplayer.R.id.epPlayerView
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.source.MediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
import com.google.android.exoplayer2.util.Util

class MainActivity : AppCompatActivity() {
    private lateinit var mediaUri: Uri
    private lateinit var mediaItem: MediaItem
    private lateinit var mediaSource: MediaSource
    private lateinit var userAgent: DefaultDataSourceFactory
    private lateinit var epPlayerView: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        exoPlayer()
    }

    private fun exoPlayer(){
        val exoPlayer =
            SimpleExoPlayer.Builder(baseContext).build() // uses builder instead of factory
        epPlayerView.
        mediaSessionPlayback()

        mediaUri = Uri.parse(UriAssetsConstants.fireside) //via file
        userAgent = DefaultDataSourceFactory(
            baseContext,
            Util.getUserAgent(baseContext, R.string.app_name.toString())
        )
        mediaItem = MediaItem.fromUri(mediaUri)

        mediaSource = ProgressiveMediaSource.Factory(userAgent).createMediaSource(mediaItem)
        exoPlayer.setMediaSource(mediaSource)
        exoPlayer.prepare()
    }

    private fun mediaSessionPlayback(){
        val mediaSession = MediaSession(baseContext, "MainActivity")

        val playbackStateBuilder = PlaybackState.Builder()

        playbackStateBuilder.setActions(PlaybackState.ACTION_PLAY)
        playbackStateBuilder.setActions(PlaybackState.ACTION_PAUSE)
        playbackStateBuilder.setActions(PlaybackState.ACTION_FAST_FORWARD)

        mediaSession.setPlaybackState(playbackStateBuilder.build())
        mediaSession.isActive = true
    }
}